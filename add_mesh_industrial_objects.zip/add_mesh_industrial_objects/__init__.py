# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
#
#Inspired by add_mesh_extra_objects

bl_info = {
    "name": "Industrial Objects",
    "author": "Laurent Tesson",
    "version": (1, 5, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Mesh > Beam Builder",
    "description": "Add Industrial mesh object types",
    "warning": "",
    "wiki_url": "",
    "category": "Add Mesh",
}


if "bpy" in locals():
    import importlib
    importlib.reload(add_lbeam_object)
    importlib.reload(add_tbeam_object)
    importlib.reload(add_ubeam_object)
    importlib.reload(add_ibeam_object)
    importlib.reload(add_zbeam_object)
    importlib.reload(add_ombeam_object)
    importlib.reload(add_bbeam_object)
    importlib.reload(add_bsbeam_object)
    importlib.reload(add_obeam_object)
    importlib.reload(add_pbeam_object)
else:
    from . import add_lbeam_object
    from . import add_tbeam_object
    from . import add_ubeam_object
    from . import add_ibeam_object
    from . import add_zbeam_object
    from . import add_ombeam_object
    from . import add_bbeam_object
    from . import add_bsbeam_object
    from . import add_obeam_object
    from . import add_pbeam_object

import bpy
import blf
import os
#from add_lbeam_object import *
from bpy.types import Menu


class VIEW3D_MT_mesh_industrial_add(Menu):
    # Define the "Profil" menu
    bl_idname = "VIEW3D_MT_mesh_industrial_add"
    bl_label = "Beam builder"
    
    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator("mesh.add_bbeamobject",
                        text="Box Beam")
        layout.operator("mesh.add_lbeamobject",
                        text="L Beam")
        layout.operator("mesh.add_tbeamobject",
                        text="T Beam")
        layout.operator("mesh.add_ubeamobject",
                        text="U Beam")
        layout.operator("mesh.add_ibeamobject",
                        text="I Beam")
        layout.operator("mesh.add_obeamobject",
                        text="O Beam")
        layout.operator("mesh.add_zbeamobject",
                        text="Z Beam")
        layout.operator("mesh.add_ombeamobject",
                        text="Omega Beam")
        layout.operator("mesh.add_bsbeamobject",
                        text="Special Box Beam")
        layout.operator("mesh.add_pbeamobject",
                        text="Other Beam")

#____
#class VIEW3D_MT_mesh_extrasIndus_add(Menu):
    # Define the "Industrial Objects" menu
#    bl_idname = "VIEW3D_MT_mesh_extrasIndus_add"
#    bl_label = "Industrial Objects"

#    def draw(self, context):
#        layout = self.layout
#        layout.operator_context = 'INVOKE_REGION_WIN'
#        layout.menu("VIEW3D_MT_mesh_industrial_add", text="Beam builder")
#        layout.separator()
        


# Register all operators and panels

# Define "Industrial" menu
#def menu_func(self, context):
#    lay_out = self.layout
#    lay_out.operator_context = 'INVOKE_REGION_WIN'

#    lay_out.separator()
#    lay_out.menu("VIEW3D_MT_mesh_extrasIndus_add",
#                text="Industrial Objects")
#    lay_out.separator()

# Register all operators and panels

# Define "Beam Builder" menu
def menu_func(self, context):
    lay_out = self.layout
    lay_out.operator_context = 'INVOKE_REGION_WIN'

    lay_out.separator()
    lay_out.menu("VIEW3D_MT_mesh_industrial_add",
                text="Beam Builder")
    lay_out.separator()
#____    

class IO_Prefs(bpy.types.AddonPreferences):
    bl_idname = __name__
    # here you define the addons customizable props
    scaleMesh:  bpy.props.FloatProperty(default=1)
    resolutionRadius: bpy.props.IntProperty(default=10)
    # here you specify how they are drawn
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        split = box.split()
        col = split.column() 
        # Layout ---------------------------------------------------------------- #
        col.label(text="Default Values:")
        col.prop(self, "scaleMesh",text="Scale Mesh")
        col.label(text="Scale Mesh: (ex: 1 -> 1 = 1 meter, 1000 -> 1 = 1 millimeter in scene)")
        col.separator()
        col.prop(self, "resolutionRadius",text="Resolution radius")
        
        
# Register
classes = [
    VIEW3D_MT_mesh_industrial_add,    
#    VIEW3D_MT_mesh_extrasIndus_add,
    add_lbeam_object.OBJECT_OT_add_lbeamobject,
    add_tbeam_object.OBJECT_OT_add_tbeamobject,
    add_ubeam_object.OBJECT_OT_add_ubeamobject,
    add_ibeam_object.OBJECT_OT_add_ibeamobject,
    add_zbeam_object.OBJECT_OT_add_zbeamobject,
    add_ombeam_object.OBJECT_OT_add_ombeamobject,
    add_bbeam_object.OBJECT_OT_add_bbeamobject,
    add_bsbeam_object.OBJECT_OT_add_bsbeamobject,
    add_obeam_object.OBJECT_OT_add_obeamobject,
    add_pbeam_object.OBJECT_OT_add_pbeamobject,
    IO_Prefs,
]

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    # Add "Industrial" menu to the "Add Mesh" menu
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)    
   
    bpy.types.Object.IO_scaleMesh = bpy.props.FloatProperty(
    name="Scale Mesh",
    description="Scale Mesh",
    min=0.01, max=1000,
    default = bpy.context.preferences.addons[__name__].preferences.scaleMesh,
    )
    
    bpy.types.Object.IO_resolutionRadius = bpy.props.IntProperty(
    name="Resolution radius",
    description="Resolution radius",
    min=1, max=1000,
    default = bpy.context.preferences.addons[__name__].preferences.resolutionRadius,
    )
    

def unregister():
    # Remove "Industrial" menu from the "Add Mesh" menu.
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()
