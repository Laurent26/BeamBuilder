# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "Box Beam",
    "author": "Laurent Tesson",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "",
    "description": "Adds a Box Beam Profil",
    "warning": "",
    "wiki_url": "",
    "category": "",
}

import bpy
import mathutils
import os
from math import *
import math
from bpy.types import Operator
from bpy.props import FloatVectorProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector
from bpy.props import (
        BoolProperty,
        EnumProperty,
        FloatProperty,
        IntProperty,
        )
        
def add_bbeamobject(self, context, prefs):
    scaleBeam = (prefs.scaleMesh)
    xBeam = ((self.beamX)/scaleBeam)
    yBeam = ((self.beamY)/scaleBeam)
    zBeam = ((self.beamZ)/scaleBeam)
    eZ = 0
    nbZ = 1
    wBeam = ((self.beamW)/scaleBeam)
    rABeam = ((self.rA)/scaleBeam)
    rBBeam = ((self.rB)/scaleBeam)
    resolA = self.resolutionA

    if zBeam > 0:
        nbZ = 2
    
    verts = []
    
    for i in range(0, nbZ):
        verts.append((0, rBBeam, eZ))
        verts.append((wBeam, rABeam+wBeam, eZ))
        verts.append((0, yBeam-rBBeam, eZ))
        verts.append((wBeam, yBeam-rABeam-wBeam, eZ))
        #arc
        i = 1
        invI = resolA - 1
        for i in range(1, resolA):
            x_float = ((sin(math.radians((90/resolA)*invI)))*rBBeam*(-1))+(rBBeam)
            y_float = ((cos(math.radians((90/resolA)*invI)))*rBBeam)+(yBeam-rBBeam)
            verts.append((x_float, y_float, eZ))
            x_float = ((sin(math.radians((90/resolA)*invI)))*rABeam*(-1))+(rABeam+wBeam)
            y_float = ((cos(math.radians((90/resolA)*invI)))*rABeam)+(yBeam-rABeam-wBeam)
            verts.append((x_float, y_float, eZ))
            invI = invI - 1 
        verts.append((rBBeam, yBeam, eZ))
        verts.append((wBeam+rABeam, yBeam-wBeam, eZ))
        verts.append((xBeam-rBBeam, yBeam, eZ))
        verts.append((xBeam-wBeam-rABeam, yBeam-wBeam, eZ))
        #arc
        i = 1
        for i in range(1, resolA):
            x_float = ((sin(math.radians((90/resolA)*i)))*rBBeam)+(xBeam-rBBeam)
            y_float = ((cos(math.radians((90/resolA)*i)))*rBBeam)+(yBeam-rBBeam)
            verts.append((x_float, y_float, eZ))
            x_float = ((sin(math.radians((90/resolA)*i)))*rABeam)+(xBeam-rABeam-wBeam)
            y_float = ((cos(math.radians((90/resolA)*i)))*rABeam)+(yBeam-rABeam-wBeam)
            verts.append((x_float, y_float, eZ)) 
        verts.append((xBeam, yBeam-rBBeam, eZ))
        verts.append((xBeam-wBeam, yBeam-wBeam-rABeam, eZ))
        verts.append((xBeam, rBBeam, eZ))
        verts.append((xBeam-wBeam, rABeam+wBeam, eZ))
        #arc
        i = 1
        invI = resolA - 1
        for i in range(1, resolA):
            x_float = ((sin(math.radians((90/resolA)*invI)))*rBBeam)+(xBeam-rBBeam)
            y_float = ((cos(math.radians((90/resolA)*invI)))*rBBeam*(-1))+(rBBeam)
            verts.append((x_float, y_float, eZ))
            x_float = ((sin(math.radians((90/resolA)*invI)))*rABeam)+(xBeam-rABeam-wBeam)
            y_float = ((cos(math.radians((90/resolA)*invI)))*rABeam*(-1))+(rABeam+wBeam)
            verts.append((x_float, y_float, eZ))
            invI = invI - 1  
        verts.append((xBeam-rBBeam, 0, eZ))
        verts.append((xBeam-rABeam-wBeam, wBeam, eZ))
        verts.append((rBBeam, 0, eZ))
        verts.append((rABeam+wBeam, wBeam, eZ))
        #arc
        i = 1
        for i in range(1, resolA):
            x_float = ((sin(math.radians((90/resolA)*i)))*rBBeam*(-1))+(rBBeam)
            y_float = ((cos(math.radians((90/resolA)*i)))*rBBeam*(-1))+(rBBeam)
            verts.append((x_float, y_float, eZ))
            x_float = ((sin(math.radians((90/resolA)*i)))*rABeam*(-1))+(rABeam+wBeam)
            y_float = ((cos(math.radians((90/resolA)*i)))*rABeam*(-1))+(rABeam+wBeam)
            verts.append((x_float, y_float, eZ))
        eZ = zBeam
    
    edges = []
    
    n_verts = len(verts)
    nbFace = (int)(n_verts/2)-1
    nbforE = (int)(n_verts/2)-1
    
    faces = []    

    if zBeam == 0: 
        j = 0
        for i in range(0, nbFace):
            faces.append((j, j+1, j+3, j+2))
            j = j + 2
        faces.append((n_verts-2, n_verts-1, 1, 0))
    else:
        nbFace = (int)(n_verts/4)-1
        j = 0
        for i in range(0, nbFace):
            faces.append((j, j+1, j+3, j+2))
            j = j + 2
        faces.append((nbforE-1, nbforE, 1, 0))
        j = nbforE + 1
        for i in range(0, nbFace):
            faces.append((j, j+1, j+3, j+2))
            j = j + 2 
        faces.append((n_verts-2, n_verts-1, nbforE+2, nbforE+1))
        j = 0
        for i in range(0, nbFace):
            faces.append((j, j+nbforE+1, j+nbforE+3, j+2))
            faces.append((j+1, j+nbforE+2, j+nbforE+4, j+3))
            j = j + 2
        faces.append((nbforE-1, 0, nbforE+1, n_verts-2))
        faces.append((nbforE, 1, nbforE+2, n_verts-1))
    
    mesh = bpy.data.meshes.new(name="Box_Beam")
    mesh.from_pydata(verts, edges, faces)
    object_data_add(context, mesh, operator=self)
    
    if self.rDouble:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.remove_doubles()
        bpy.ops.object.mode_set(mode='OBJECT')

    if zBeam == 0:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.normals_make_consistent(inside=True)
        bpy.ops.object.mode_set(mode='OBJECT')
    else:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')
    

class OBJECT_OT_add_bbeamobject(Operator, AddObjectHelper):
    """Create a new Box Beam"""
    bl_idname = "mesh.add_bbeamobject"
    bl_label = "Add Box Beam"
    bl_options = {'REGISTER', 'UNDO'}

    beamX: FloatProperty(
            name="Length X",
            min=0.001, max=10000,
            default=2
            )
    beamY: FloatProperty(
            name="Length Y",
            min=0.001, max=10000,
            default=2
            )
    beamZ: FloatProperty(
            name="Length Z",
            min=0, max=100000,
            default=2
            )
    beamW: FloatProperty(
            name="Thickness",
            min=0.001, max=1000,
            default=0.2
            )
    rA: FloatProperty(
            name="Radius 1",
            min=0, max=1000,
            default=0.2
            )    
    rB: FloatProperty(
            name="Radius 2",
            min=0, max=1000,
            default=0.4
            )
    resolutionA: IntProperty(
            name="Resolution",
            min=1, max=1000,
            default=10
            )
    rDouble: BoolProperty(
            name="Remove doubles vertices",
            default=True,
            description="Remove doubles vertices"
            )
    adjDim: BoolProperty(
                name="Default values",
                description="Default values",
                default=True
                )
    startlocation:  FloatVectorProperty(name = "",
                    description = "Start location",
                    default = (0.0, 0.0, 0.0),
                    subtype = 'XYZ')
    rotation_euler: FloatVectorProperty(
                name="",
                description="Rotation",
                default=(0.0, 0.0, 0.0),
                subtype='EULER'
                )    
    Z_Origin:  EnumProperty(
                items=(
                ('0', "-Z", "-Z"),
                ("1", "0", "0"),
                ("2", "+Z", "+Z")
                ),
                description="Z axis origin",
                default="1"
                )
    X_Origin:  EnumProperty(
                items=(
                ('0', "-X", "-X"),
                ("1", "0", "0"),
                ("2", "+X", "+X")
                ),
                description="X axis origin",
                default="1"
                )
    Y_Origin:  EnumProperty(
                items=(
                ('0', "-Y", "-Y"),
                ("1", "0", "0"),
                ("2", "+Y", "+Y")
                ),
                description="Y axis origin",
                default="1"
                )
    
    def draw(self, context):
        layout = self.layout
        layout = self.layout
        box = layout.box()
        box.label(text="Beam size:")
        col = box.column(align=True)
        col.prop(self, "beamX")
        col.prop(self, "beamY")
        col.prop(self, "beamZ")
        col.separator()
        col.prop(self, "beamW")
        col.separator()
        col.prop(self, "rA")
        col.prop(self, "rB")
        col.prop(self, "resolutionA")        
        col.separator()
        col.prop(self, "rDouble")
        col.separator()
        col.prop(self, "adjDim", toggle=True)
        box = layout.box()
        box.label(text="Geometry origin:")
        row = box.row(align=True)
        row.prop(self, "X_Origin", text="X")
        row.separator()
        row.prop(self, "Y_Origin", text="Y")               
        row.separator()               
        row.prop(self, "Z_Origin", text="Z")
        box = layout.box()
        box.label(text="Location:")
        box.prop(self, "startlocation")
        box = layout.box()
        box.label(text="Rotation:")
        box.prop(self, "rotation_euler")
        
        
    def execute(self, context):        
        prefs = bpy.context.preferences.addons['add_mesh_industrial_objects'].preferences
        scale = prefs.scaleMesh
        if self.adjDim:
            self.beamX = 2*scale
            self.beamY = 2*scale
            self.beamZ = 2*scale
            self.beamW = 0.2*scale
            self.rA = 0.2*scale
            self.resolutionA = 10
            self.rB = 0.4*scale
            self.adjDim = False
        
        add_bbeamobject(self, context, prefs)
        
        xValueC = bpy.context.scene.cursor.location[0]
        yValueC = bpy.context.scene.cursor.location[1]
        zValueC = bpy.context.scene.cursor.location[2]
        
        xValueBeam = self.beamX/scale
        yValueBeam = self.beamY/scale
        zValueBeam = self.beamZ/scale          
               
        if self.Z_Origin == "1":
            bpy.context.scene.cursor.location[2] = zValueC + (zValueBeam/2)            
        elif self.Z_Origin == "2":
            bpy.context.scene.cursor.location[2] = zValueC + zValueBeam            
        
        if self.Y_Origin == "1":            
            bpy.context.scene.cursor.location[1] = yValueC + (yValueBeam/2)
        elif self.Y_Origin == "2":
            bpy.context.scene.cursor.location[1] = yValueC + yValueBeam
            
        if self.X_Origin == "0":
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC
        elif self.X_Origin == "1":
            bpy.context.scene.cursor.location[0] = xValueC + (xValueBeam/2)
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC
        elif self.X_Origin == "2":
            bpy.context.scene.cursor.location[0] = xValueC + xValueBeam
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC           
        
        bpy.context.object.rotation_euler = self.rotation_euler
        
        bpy.context.object.location[0] = xValueC + self.startlocation[0]
        bpy.context.object.location[1] = yValueC + self.startlocation[1]
        bpy.context.object.location[2] = zValueC + self.startlocation[2]
        
        return {'FINISHED'}


# Registration

def register():
    bpy.utils.register_class(OBJECT_OT_add_bbeamobject)
    

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_add_bbeamobject)
    

if __name__ == "__main__":
    register()