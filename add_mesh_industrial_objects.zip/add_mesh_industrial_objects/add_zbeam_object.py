# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "L Beam",
    "author": "Laurent Tesson",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "",
    "description": "Adds a Z Beam Profil",
    "warning": "",
    "wiki_url": "",
    "category": "",
}

import bpy
import mathutils
import os
from math import *
import math
from bpy.types import Operator
from bpy.props import FloatVectorProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector
from bpy.props import (
        BoolProperty,
        EnumProperty,
        FloatProperty,
        IntProperty,
        )
        
def add_zbeamobject(self, context, prefs):
    scaleBeam = (prefs.scaleMesh)
    ABeam = ((self.beamA)/scaleBeam)
    BBeam = ((self.beamB)/scaleBeam)
    CBeam = ((self.beamC)/scaleBeam)
    zBeam = ((self.beamZ)/scaleBeam)
    eZ = 0
    nbZ = 1
    TABeam = ((self.beamTA)/scaleBeam)
    TBBeam = ((self.beamTB)/scaleBeam)
    TCBeam = ((self.beamTC)/scaleBeam)
    rABeam = ((self.rA)/scaleBeam)
    rBBeam = ((self.rB)/scaleBeam)
    rCBeam = ((self.rC)/scaleBeam)
    rDBeam = ((self.rD)/scaleBeam)
    resolA = self.resolutionA
    resolB = self.resolutionB
    resolC = self.resolutionC
    resolD = self.resolutionD

    if zBeam > 0:
        nbZ = 2

    verts = []
    
    for i in range(0, nbZ):
        verts.append((0, 0, eZ))
        verts.append((0, TABeam, eZ))
        verts.append((ABeam-TBBeam-rABeam, TABeam, eZ))
        #arc
        i = 1
        for i in range(1, resolA):
            x_float = ((sin(math.radians((90/resolA)*i)))*rABeam)+(ABeam-TBBeam-rABeam)
            y_float = ((cos(math.radians((90/resolA)*i)))*rABeam*(-1))+(TABeam+rABeam)
            verts.append((x_float, y_float, eZ))
            
        verts.append((ABeam-TBBeam, TABeam+rABeam, eZ))
        verts.append((ABeam-TBBeam, BBeam-rBBeam, eZ))
        #arc
        i = 1
        invI = resolB - 1
        for i in range(1, resolB):
            x_float = ((sin(math.radians((90/resolB)*invI)))*rBBeam*(-1))+(ABeam-TBBeam+rBBeam)
            y_float = ((cos(math.radians((90/resolB)*invI)))*rBBeam)+(BBeam-rBBeam)
            verts.append((x_float, y_float, eZ))
            invI = invI - 1    
            
        verts.append((ABeam-TBBeam+rBBeam, BBeam, eZ))
        verts.append((ABeam+CBeam-TBBeam, BBeam, eZ))
        verts.append((ABeam+CBeam-TBBeam, BBeam-TCBeam, eZ))
        verts.append((ABeam+rCBeam, BBeam-TCBeam, eZ))
        #arc
        i = 1
        for i in range(1, resolC):
            x_float = ((sin(math.radians((90/resolC)*i)))*rCBeam*(-1))+(ABeam+rCBeam)
            y_float = ((cos(math.radians((90/resolC)*i)))*rCBeam)+(BBeam-TCBeam-rCBeam)
            verts.append((x_float, y_float, eZ))
            
        verts.append((ABeam, BBeam-TCBeam-rCBeam, eZ))
        verts.append((ABeam, rDBeam, eZ))
        #arc
        i = 1
        invI = resolD - 1
        for i in range(1, resolD):
            x_float = ((sin(math.radians((90/resolD)*invI)))*rDBeam)+(ABeam-rDBeam)
            y_float = ((cos(math.radians((90/resolD)*invI)))*rDBeam*(-1))+(rDBeam)
            verts.append((x_float, y_float, eZ))
            invI = invI - 1
        verts.append((ABeam-rDBeam, 0, eZ))
        eZ = zBeam

    edges = []
    
    n_verts = len(verts)
    nbforE = (int)(n_verts/2)-1
    
    faces = []    
    if zBeam == 0:   
        faces.append(range(n_verts))
    else:
        faces.append(range(0, nbforE+1))
        faces.append(range(nbforE+1, n_verts))
        j = 0
        for i in range(0, nbforE):
            faces.append((j, j+nbforE+1, j+nbforE+2, j+1))
            j = j + 1
        faces.append((nbforE, n_verts-1, nbforE+1, 0))
    
    mesh = bpy.data.meshes.new(name="Z_Beam")
    mesh.from_pydata(verts, edges, faces)
    object_data_add(context, mesh, operator=self)
    
    if self.rDouble:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.remove_doubles()
        bpy.ops.object.mode_set(mode='OBJECT')

    if zBeam == 0:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.normals_make_consistent(inside=True)
        bpy.ops.object.mode_set(mode='OBJECT')
    else:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')
    

class OBJECT_OT_add_zbeamobject(Operator, AddObjectHelper):
    """Create a new Z Beam"""
    bl_idname = "mesh.add_zbeamobject"
    bl_label = "Add Z Beam"
    bl_options = {'REGISTER', 'UNDO'}

    beamA: FloatProperty(
            name="Length A",
            min=0.001, max=10000,
            default=1
            )
    beamB: FloatProperty(
            name="Length B",
            min=0.001, max=10000,
            default=1.4
            )
    beamC: FloatProperty(
            name="Length C",
            min=0.001, max=10000,
            default=1
            )
    beamZ: FloatProperty(
            name="Length Z",
            min=0, max=100000,
            default=2
            )
    beamTA: FloatProperty(
            name="Thickness 1",
            min=0.001, max=1000,
            default=0.06
            )
    beamTB: FloatProperty(
            name="Thickness 2",
            min=0.001, max=1000,
            default=0.06
            )
    beamTC: FloatProperty(
            name="Thickness 3",
            min=0.001, max=1000,
            default=0.06
            )
    rA: FloatProperty(
            name="Radius 1",
            min=0, max=1000,
            default=0.06
            )
    resolutionA: IntProperty(
            name="Resolution",
            min=1, max=1000,
            default=10
            )
    rB: FloatProperty(
            name="Radius 2",
            min=0, max=1000,
            default=0.12
            )
    resolutionB: IntProperty(
            name="Resolution",
            min=1, max=1000,
            default=10
            )
    rC: FloatProperty(
            name="Radius 3",
            min=0, max=1000,
            default=0.06
            )
    resolutionC: IntProperty(
            name="Resolution",
            min=1, max=1000,
            default=10
            )
    rD: FloatProperty(
            name="Radius 4",
            min=0, max=1000,
            default=0.12
            )
    resolutionD: IntProperty(
            name="Resolution",
            min=1, max=1000,
            default=10
            )
    rDouble: BoolProperty(
            name="Remove doubles vertices",
            default=True,
            description="Remove doubles vertices"
            )
    adjDim: BoolProperty(
                name="Default values",
                description="Default values",
                default=True
                )
    startlocation:  FloatVectorProperty(name = "",
                    description = "Start location",
                    default = (0.0, 0.0, 0.0),
                    subtype = 'XYZ')
    rotation_euler: FloatVectorProperty(
                name="",
                description="Rotation",
                default=(0.0, 0.0, 0.0),
                subtype='EULER'
                )    
    Z_Origin:  EnumProperty(
                items=(
                ('0', "-Z", "-Z"),
                ("1", "0", "0"),
                ("2", "+Z", "+Z")
                ),
                description="Z axis origin",
                default="1"
                )
    X_Origin:  EnumProperty(
                items=(
                ('0', "-X", "-X"),
                ("1", "0", "0"),
                ("2", "+X", "+X")
                ),
                description="X axis origin",
                default="1"
                )
    Y_Origin:  EnumProperty(
                items=(
                ('0', "-Y", "-Y"),
                ("1", "0", "0"),
                ("2", "+Y", "+Y")
                ),
                description="Y axis origin",
                default="1"
                )
    
    def draw(self, context):
        layout = self.layout
        layout = self.layout
        box = layout.box()
        box.label(text="Beam size:")
        col = box.column(align=True)
        col.prop(self, "beamA")
        col.prop(self, "beamB")
        col.prop(self, "beamC")
        col.prop(self, "beamZ")
        col.separator()
        col.prop(self, "beamTA")
        col.prop(self, "beamTB")
        col.prop(self, "beamTC")
        col.separator()
        col.prop(self, "rA")
        col.prop(self, "resolutionA")
        col.separator()
        col.prop(self, "rB")
        col.prop(self, "resolutionB")
        col.separator()
        col.prop(self, "rC")
        col.prop(self, "resolutionC")
        col.separator()
        col.prop(self, "rD")
        col.prop(self, "resolutionD")
        col.separator()
        col.prop(self, "rDouble")
        col.separator()
        col.prop(self, "adjDim", toggle=True)
        box = layout.box()
        box.label(text="Geometry origin:")
        row = box.row(align=True)
        row.prop(self, "X_Origin", text="X")
        row.separator()
        row.prop(self, "Y_Origin", text="Y")               
        row.separator()               
        row.prop(self, "Z_Origin", text="Z")
        box = layout.box()
        box.label(text="Location:")
        box.prop(self, "startlocation")
        box = layout.box()
        box.label(text="Rotation:")
        box.prop(self, "rotation_euler")
        
        
    def execute(self, context):        
        prefs = bpy.context.preferences.addons['add_mesh_industrial_objects'].preferences
        scale = prefs.scaleMesh
        if self.adjDim:
            self.beamA = 1*scale
            self.beamB = 1.4*scale
            self.beamC = 1*scale
            self.beamZ = 2*scale
            self.beamTA = 0.06*scale
            self.beamTB = 0.06*scale
            self.beamTC = 0.06*scale
            self.rA = 0.06*scale
            self.resolutionA = 10
            self.rB = 0.12*scale
            self.resolutionB = 10
            self.rC = 0.06*scale
            self.resolutionC = 10
            self.rD = 0.12*scale
            self.resolutionD = 10
            self.adjDim = False
        
        add_zbeamobject(self, context, prefs)
        
        xValueC = bpy.context.scene.cursor.location[0]
        yValueC = bpy.context.scene.cursor.location[1]
        zValueC = bpy.context.scene.cursor.location[2]
        
        xValueBeam = (self.beamA/scale)+(self.beamC/scale)-(self.beamTB/scale)
        yValueBeam = self.beamB/scale
        zValueBeam = self.beamZ/scale          
               
        if self.Z_Origin == "1":
            bpy.context.scene.cursor.location[2] = zValueC + (zValueBeam/2)            
        elif self.Z_Origin == "2":
            bpy.context.scene.cursor.location[2] = zValueC + zValueBeam            
        
        if self.Y_Origin == "1":            
            bpy.context.scene.cursor.location[1] = yValueC + (yValueBeam/2)
        elif self.Y_Origin == "2":
            bpy.context.scene.cursor.location[1] = yValueC + yValueBeam
            
        if self.X_Origin == "0":
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC
        elif self.X_Origin == "1":
            bpy.context.scene.cursor.location[0] = xValueC + (xValueBeam/2)
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC
        elif self.X_Origin == "2":
            bpy.context.scene.cursor.location[0] = xValueC + xValueBeam
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC           
        
        bpy.context.object.rotation_euler = self.rotation_euler
        
        bpy.context.object.location[0] = xValueC + self.startlocation[0]
        bpy.context.object.location[1] = yValueC + self.startlocation[1]
        bpy.context.object.location[2] = zValueC + self.startlocation[2]
        
        return {'FINISHED'}


# Registration


def register():
    bpy.utils.register_class(OBJECT_OT_add_zbeamobject)
    

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_add_zbeamobject)
    

if __name__ == "__main__":
    register()